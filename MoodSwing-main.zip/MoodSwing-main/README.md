# MoodSwing

<h2>Mood Swing is an emotion based music player</h2>
<h3>It detect our emotion and play music based on your emotion</h3>
 The main motivation for this system is ,In real life, people express their emotion on their face to show their psychological activities and attitudes in the interaction with other people. 

  The primary focus of this project is to determine which emotion an input image that contains one facial emotion belongs to. 
  The goals of this project are to establish a model that can classify 6 basic emotions: happy, sad, surprise, angry, neutral, and fear
  
  #Working Model
  
  <img src="Screenshot 2022-06-08 210557.png">
